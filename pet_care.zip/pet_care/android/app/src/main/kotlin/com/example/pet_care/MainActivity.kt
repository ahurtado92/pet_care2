package com.example.pet_care

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
